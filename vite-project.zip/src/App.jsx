import BridgeModel from "./components/BridgeModel";

function App() {
  return (
    <div style={{ width: "100%", height: "100vh" }}>
      <BridgeModel />
    </div>
  );
}

export default App;