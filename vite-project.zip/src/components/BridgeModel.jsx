import { useState, useRef, useEffect } from "react";

// ─── COLOURS ──────────────────────────────────────────────────────────────────
const COL = {
  steel:      "#5a7fa8",
  steelDark:  "#2d4a6a",
  steelLight: "#8ab4d8",
  checker:    "#b87333",
  checkerDk:  "#7a4a1e",
  checkerLt:  "#e09a55",
  support:    "#4a8a4a",
  supportDk:  "#2a5a2a",
  railing:    "#888",
  railingLt:  "#bbb",
  bg:         "#0a0f18",
  panel:      "#111827",
  border:     "#1f2937",
  green:      "#22c55e",
  yellow:     "#eab308",
  blue:       "#60a5fa",
  red:        "#ef4444",
  text:       "#f1f5f9",
  muted:      "#94a3b8",
};

// ─── 3-D MATH ──────────────────────────────────────────────────────────────────
function proj(x, y, z, rx, ry, cx, cy, scale = 1) {
  const cosX = Math.cos(rx), sinX = Math.sin(rx);
  const cosY = Math.cos(ry), sinY = Math.sin(ry);
  const y2 = y * cosX - z * sinX;
  const z2 = y * sinX + z * cosX;
  const x2 = x * cosY + z2 * sinY;
  const z3 = -x * sinY + z2 * cosY;
  const sc = (600 / (600 + z3 * 0.3)) * scale;
  return { sx: cx + x2 * sc, sy: cy + y2 * sc, d: z3 };
}

function polygon(ctx, pts, fill, stroke, lw = 0.8) {
  if (pts.length < 2) return;
  ctx.beginPath();
  ctx.moveTo(pts[0].sx, pts[0].sy);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].sx, pts[i].sy);
  ctx.closePath();
  if (fill)  { ctx.fillStyle = fill;   ctx.fill(); }
  if (stroke){ ctx.strokeStyle = stroke; ctx.lineWidth = lw; ctx.stroke(); }
}

// ─── BRIDGE GEOMETRY (in cm, bridge 427cm × 76cm) ────────────────────────────
// U-channel: 11″ wide = 28cm  →  3+5+3 in = 7.6+12.7+7.6 cm flanges+web
const BL   = 210;   // half-length = 420 cm total → scaled to fit
const BW   = 38;    // half-width  = 76 cm
const FL   = 7.6;   // flange width
const WH   = 12;    // web height  (5 inch)
const T    = 3;     // 6mm thickness visual
const DT   = 2.5;   // checker plate 4mm thickness
const RAIL_H = 45;  // railing height 3ft → 91cm but scaled
const RAIL_T = 1.8; // pipe radius

// Support X positions (6 supports evenly spaced)
const SUPS = [-140, -84, -28, 28, 84, 140];

// ─── DRAW COMPLETE BRIDGE ─────────────────────────────────────────────────────
function drawComplete(ctx, W, H, rx, ry) {
  ctx.clearRect(0, 0, W, H);

  // background
  const bg = ctx.createRadialGradient(W/2, H/2, 20, W/2, H/2, W*0.7);
  bg.addColorStop(0, "#0d1520"); bg.addColorStop(1, "#060a10");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

  const cx = W/2, cy = H/2 + 10;
  const sc = W < 400 ? 0.72 : 1;
  const p = (x,y,z) => proj(x,y,z,rx,ry,cx,cy,sc);

  // ── Shadow
  ctx.globalAlpha = 0.18;
  polygon(ctx,
    [p(-BL-5,T+DT+5,-BW-5),p(BL+5,T+DT+5,-BW-5),p(BL+5,T+DT+5,BW+5),p(-BL-5,T+DT+5,BW+5)],
    "#000");
  ctx.globalAlpha = 1;

  // ── Left U-Channel  (z = BW → BW-FL  bottom flange, web, top flange)
  function drawUchan(zOuter, zInner, flip) {
    const zo = zOuter, zi = zInner;
    const mid = flip ? zo - FL : zo + FL;
    const bot = T;

    // Bottom flange
    polygon(ctx,[p(-BL,0,zo),p(BL,0,zo),p(BL,0,zi),p(-BL,0,zi)],COL.steelDark,"#000");
    polygon(ctx,[p(-BL,-bot,zo),p(BL,-bot,zo),p(BL,-bot,zi),p(-BL,-bot,zi)],COL.steel,"#0008");
    // Bottom flange sides
    polygon(ctx,[p(-BL,0,zo),p(-BL,-bot,zo),p(BL,-bot,zo),p(BL,0,zo)], COL.steelDark,"#000");
    polygon(ctx,[p(-BL,0,zi),p(-BL,-bot,zi),p(BL,-bot,zi),p(BL,0,zi)], COL.steelLight,"#000");

    // Web (vertical side plate)
    polygon(ctx,
      [p(-BL,-bot,zo),p(BL,-bot,zo),p(BL,-bot-WH,zo),p(-BL,-bot-WH,zo)],
      COL.steelDark,"#000");
    polygon(ctx,
      [p(-BL,-bot,zi),p(BL,-bot,zi),p(BL,-bot-WH,zi),p(-BL,-bot-WH,zi)],
      COL.steelLight,"#000");
    polygon(ctx,
      [p(-BL,-bot,zo),p(-BL,-bot,zi),p(-BL,-bot-WH,zi),p(-BL,-bot-WH,zo)],
      COL.steel,"#000");
    polygon(ctx,
      [p(BL,-bot,zo),p(BL,-bot,zi),p(BL,-bot-WH,zi),p(BL,-bot-WH,zo)],
      COL.steelLight,"#000");

    // Top flange
    const ty = -bot-WH;
    polygon(ctx,[p(-BL,ty,zo),p(BL,ty,zo),p(BL,ty,zi),p(-BL,ty,zi)],COL.steelLight,"#000");
    polygon(ctx,[p(-BL,ty-T,zo),p(BL,ty-T,zo),p(BL,ty-T,zi),p(-BL,ty-T,zi)],COL.steel,"#0008");
    polygon(ctx,[p(-BL,ty,zo),p(-BL,ty-T,zo),p(BL,ty-T,zo),p(BL,ty,zo)],COL.steelDark,"#000");
    polygon(ctx,[p(-BL,ty,zi),p(-BL,ty-T,zi),p(BL,ty-T,zi),p(BL,ty,zi)],COL.steelLight,"#000");
  }

  const yTop = -(T + WH + T);   // top of U channel
  drawUchan( BW,  BW-FL, false);
  drawUchan(-BW, -BW+FL, true);

  // ── Center supports
  SUPS.forEach(sx => {
    const sw = 3, sd = BW - FL;
    polygon(ctx,
      [p(sx-sw,yTop,-sd),p(sx+sw,yTop,-sd),p(sx+sw,yTop,sd),p(sx-sw,yTop,sd)],
      COL.support,"#000");
    polygon(ctx,
      [p(sx-sw,yTop-T,-sd),p(sx+sw,yTop-T,-sd),p(sx+sw,yTop-T,sd),p(sx-sw,yTop-T,sd)],
      COL.supportDk,"#000");
    polygon(ctx,
      [p(sx-sw,yTop,-sd),p(sx+sw,yTop,-sd),p(sx+sw,yTop-T,-sd),p(sx-sw,yTop-T,-sd)],
      COL.supportDk,"#000");
    polygon(ctx,
      [p(sx-sw,yTop,sd),p(sx+sw,yTop,sd),p(sx+sw,yTop-T,sd),p(sx-sw,yTop-T,sd)],
      COL.support,"#000");
  });

  // ── Checker Plate Deck
  const dy = yTop - T;
  const dx = BW - FL;
  polygon(ctx,[p(-BL,dy,-dx),p(BL,dy,-dx),p(BL,dy,dx),p(-BL,dy,dx)],COL.checker,COL.checkerDk);
  // checker texture
  ctx.save(); ctx.globalAlpha=0.22;
  for(let xi=-BL;xi<BL;xi+=14){
    for(let zi=0;zi<2;zi++){
      const zs=zi===0?-dx:0, ze=zi===0?0:dx;
      if((Math.floor((xi+BL)/14)+zi)%2===0)
        polygon(ctx,[p(xi,dy-1.5,zs),p(xi+14,dy-1.5,zs),p(xi+14,dy-1.5,ze),p(xi,dy-1.5,ze)],COL.checkerLt);
    }
  }
  ctx.restore();
  polygon(ctx,[p(-BL,dy,-dx),p(BL,dy,-dx),p(BL,dy+DT,-dx),p(-BL,dy+DT,-dx)],COL.checkerDk,"#000");
  polygon(ctx,[p(-BL,dy,dx),p(BL,dy,dx),p(BL,dy+DT,dx),p(-BL,dy+DT,dx)],COL.checker,"#000");
  polygon(ctx,[p(-BL,dy,-dx),p(-BL,dy,dx),p(-BL,dy+DT,dx),p(-BL,dy+DT,-dx)],COL.checker,"#000");
  polygon(ctx,[p(BL,dy,-dx),p(BL,dy,dx),p(BL,dy+DT,dx),p(BL,dy+DT,-dx)],COL.checkerLt,"#000");

  // ── Railings (both sides, 3ft = RAIL_H)
  const ry2 = dy - RAIL_H;
  const posts = [-BL, -BL+60, -BL+120, -60, 0, 60, BL-120, BL-60, BL];
  [dx, -dx].forEach(rz => {
    // posts
    posts.forEach(px => {
      polygon(ctx,
        [p(px-RAIL_T,dy,rz-RAIL_T),p(px+RAIL_T,dy,rz-RAIL_T),p(px+RAIL_T,ry2,rz-RAIL_T),p(px-RAIL_T,ry2,rz-RAIL_T)],
        COL.railing,"#000");
      polygon(ctx,
        [p(px-RAIL_T,dy,rz+RAIL_T),p(px+RAIL_T,dy,rz+RAIL_T),p(px+RAIL_T,ry2,rz+RAIL_T),p(px-RAIL_T,ry2,rz+RAIL_T)],
        COL.railingLt,"#000");
      polygon(ctx,
        [p(px-RAIL_T,ry2,rz-RAIL_T),p(px+RAIL_T,ry2,rz-RAIL_T),p(px+RAIL_T,ry2,rz+RAIL_T),p(px-RAIL_T,ry2,rz+RAIL_T)],
        COL.railingLt,"#000");
    });
    // Top rail
    polygon(ctx,
      [p(-BL,ry2-RAIL_T,rz-RAIL_T),p(BL,ry2-RAIL_T,rz-RAIL_T),p(BL,ry2-RAIL_T,rz+RAIL_T),p(-BL,ry2-RAIL_T,rz+RAIL_T)],
      COL.railingLt,"#000");
    polygon(ctx,
      [p(-BL,ry2,rz-RAIL_T),p(BL,ry2,rz-RAIL_T),p(BL,ry2,rz+RAIL_T),p(-BL,ry2,rz+RAIL_T)],
      COL.railing,"#000");
    // Mid rail
    const mry = dy - RAIL_H/2;
    polygon(ctx,
      [p(-BL,mry-RAIL_T,rz-RAIL_T),p(BL,mry-RAIL_T,rz-RAIL_T),p(BL,mry-RAIL_T,rz+RAIL_T),p(-BL,mry-RAIL_T,rz+RAIL_T)],
      COL.railing,"#000");
  });

  // ── Dimension annotations
  ctx.font = `bold ${W<400?8:10}px monospace`;
  ctx.textAlign = "center";
  const lA = p(-BL, dy-RAIL_H-12, 0), lB = p(BL, dy-RAIL_H-12, 0);
  ctx.beginPath(); ctx.moveTo(lA.sx,lA.sy); ctx.lineTo(lB.sx,lB.sy);
  ctx.strokeStyle="#334155"; ctx.lineWidth=1; ctx.stroke();
  ctx.fillStyle=COL.blue;
  ctx.fillText("← 14 فٹ →",(lA.sx+lB.sx)/2,(lA.sy+lB.sy)/2-6);

  const wA = p(BL+18,dy,-BW), wB = p(BL+18,dy,BW);
  ctx.beginPath(); ctx.moveTo(wA.sx,wA.sy); ctx.lineTo(wB.sx,wB.sy);
  ctx.strokeStyle="#334155"; ctx.stroke();
  ctx.fillStyle=COL.yellow;
  ctx.fillText("2.5 فٹ",(wA.sx+wB.sx)/2+10,(wA.sy+wB.sy)/2);

  const hA = p(BL+18,dy,BW), hB = p(BL+18,ry2,BW);
  ctx.beginPath(); ctx.moveTo(hA.sx,hA.sy); ctx.lineTo(hB.sx,hB.sy);
  ctx.strokeStyle="#334155"; ctx.stroke();
  ctx.fillStyle="#f472b6";
  ctx.fillText("3 فٹ",(hA.sx+hB.sx)/2+14,(hA.sy+hB.sy)/2);
}

// ─── DRAW EXPLODED VIEW ───────────────────────────────────────────────────────
function drawExploded(ctx, W, H) {
  ctx.clearRect(0, 0, W, H);
  const bg = ctx.createRadialGradient(W/2, H/2, 20, W/2, H/2, W*0.7);
  bg.addColorStop(0, "#0d1520"); bg.addColorStop(1, "#060a10");
  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);

  const rx = 0.38, ry2 = -0.55;
  const sc = W < 400 ? 0.55 : 0.75;
  const p = (x,y,z,cx,cy) => proj(x,y,z,rx,ry2,cx,cy,sc);

  const labels = [];

  // Part 1 — Left U Channel (offset up-left)
  {
    const cx=W*0.25, cy=H*0.22;
    function uc(zo,zi){
      const bot=T;
      polygon(ctx,[p(-BL,0,zo,cx,cy),p(BL,0,zo,cx,cy),p(BL,0,zi,cx,cy),p(-BL,0,zi,cx,cy)],COL.steelDark,"#0008");
      polygon(ctx,[p(-BL,-bot-WH,zo,cx,cy),p(BL,-bot-WH,zo,cx,cy),p(BL,-bot-WH,zi,cx,cy),p(-BL,-bot-WH,zi,cx,cy)],COL.steelLight,"#0008");
      polygon(ctx,[p(-BL,0,zo,cx,cy),p(BL,0,zo,cx,cy),p(BL,-bot-WH,zo,cx,cy),p(-BL,-bot-WH,zo,cx,cy)],COL.steelDark,"#000");
      polygon(ctx,[p(-BL,0,zi,cx,cy),p(BL,0,zi,cx,cy),p(BL,-bot-WH,zi,cx,cy),p(-BL,-bot-WH,zi,cx,cy)],COL.steelLight,"#000");
      polygon(ctx,[p(-BL,0,zo,cx,cy),p(-BL,0,zi,cx,cy),p(-BL,-bot-WH,zi,cx,cy),p(-BL,-bot-WH,zo,cx,cy)],COL.steel,"#000");
      polygon(ctx,[p(BL,0,zo,cx,cy),p(BL,0,zi,cx,cy),p(BL,-bot-WH,zi,cx,cy),p(BL,-bot-WH,zo,cx,cy)],COL.steelLight,"#000");
    }
    uc(8,8-FL);
    labels.push({x:cx, y:cy+45, text:"① Left U Channel — 6mm", col:COL.steelLight});
  }

  // Part 2 — Right U Channel
  {
    const cx=W*0.75, cy=H*0.22;
    function uc(zo,zi){
      const bot=T;
      polygon(ctx,[p(-BL,0,zo,cx,cy),p(BL,0,zo,cx,cy),p(BL,0,zi,cx,cy),p(-BL,0,zi,cx,cy)],COL.steelDark,"#0008");
      polygon(ctx,[p(-BL,-bot-WH,zo,cx,cy),p(BL,-bot-WH,zo,cx,cy),p(BL,-bot-WH,zi,cx,cy),p(-BL,-bot-WH,zi,cx,cy)],COL.steelLight,"#0008");
      polygon(ctx,[p(-BL,0,zo,cx,cy),p(BL,0,zo,cx,cy),p(BL,-bot-WH,zo,cx,cy),p(-BL,-bot-WH,zo,cx,cy)],COL.steelDark,"#000");
      polygon(ctx,[p(-BL,0,zi,cx,cy),p(BL,0,zi,cx,cy),p(BL,-bot-WH,zi,cx,cy),p(-BL,-bot-WH,zi,cx,cy)],COL.steelLight,"#000");
      polygon(ctx,[p(-BL,0,zo,cx,cy),p(-BL,0,zi,cx,cy),p(-BL,-bot-WH,zi,cx,cy),p(-BL,-bot-WH,zo,cx,cy)],COL.steel,"#000");
      polygon(ctx,[p(BL,0,zo,cx,cy),p(BL,0,zi,cx,cy),p(BL,-bot-WH,zi,cx,cy),p(BL,-bot-WH,zo,cx,cy)],COL.steelLight,"#000");
    }
    uc(-8+FL,-8);
    labels.push({x:cx, y:cy+45, text:"② Right U Channel — 6mm", col:COL.steelLight});
  }

  // Part 3 — 6 Center Supports
  {
    const cx=W*0.25, cy=H*0.62;
    const sw=3, sd=BW-FL;
    SUPS.forEach(sx => {
      polygon(ctx,[p(sx-sw,0,-sd,cx,cy),p(sx+sw,0,-sd,cx,cy),p(sx+sw,0,sd,cx,cy),p(sx-sw,0,sd,cx,cy)],COL.support,"#000");
      polygon(ctx,[p(sx-sw,-T,-sd,cx,cy),p(sx+sw,-T,-sd,cx,cy),p(sx+sw,-T,sd,cx,cy),p(sx-sw,-T,sd,cx,cy)],COL.supportDk,"#000");
      polygon(ctx,[p(sx-sw,0,-sd,cx,cy),p(sx+sw,0,-sd,cx,cy),p(sx+sw,-T,-sd,cx,cy),p(sx-sw,-T,-sd,cx,cy)],COL.supportDk,"#000");
      polygon(ctx,[p(sx-sw,0,sd,cx,cy),p(sx+sw,0,sd,cx,cy),p(sx+sw,-T,sd,cx,cy),p(sx-sw,-T,sd,cx,cy)],COL.support,"#000");
    });
    labels.push({x:cx, y:cy+30, text:"③ 6 Center Supports — 6mm", col:"#86efac"});
  }

  // Part 4 — Checker Plate
  {
    const cx=W*0.75, cy=H*0.62;
    const dx=BW-FL;
    polygon(ctx,[p(-BL,0,-dx,cx,cy),p(BL,0,-dx,cx,cy),p(BL,0,dx,cx,cy),p(-BL,0,dx,cx,cy)],COL.checker,COL.checkerDk);
    ctx.save(); ctx.globalAlpha=0.25;
    for(let xi=-BL;xi<BL;xi+=14){
      for(let zi=0;zi<2;zi++){
        const zs=zi===0?-dx:0,ze=zi===0?0:dx;
        if((Math.floor((xi+BL)/14)+zi)%2===0)
          polygon(ctx,[p(xi,-1.5,zs,cx,cy),p(xi+14,-1.5,zs,cx,cy),p(xi+14,-1.5,ze,cx,cy),p(xi,-1.5,ze,cx,cy)],COL.checkerLt);
      }
    }
    ctx.restore();
    polygon(ctx,[p(-BL,0,-dx,cx,cy),p(BL,0,-dx,cx,cy),p(BL,DT,-dx,cx,cy),p(-BL,DT,-dx,cx,cy)],COL.checkerDk,"#000");
    polygon(ctx,[p(-BL,0,dx,cx,cy),p(BL,0,dx,cx,cy),p(BL,DT,dx,cx,cy),p(-BL,DT,dx,cx,cy)],COL.checker,"#000");
    polygon(ctx,[p(BL,0,-dx,cx,cy),p(BL,0,dx,cx,cy),p(BL,DT,dx,cx,cy),p(BL,DT,-dx,cx,cy)],COL.checkerLt,"#000");
    labels.push({x:cx, y:cy+22, text:"④ Checker Plate — 4mm", col:"#fcd34d"});
  }

  // Part labels
  ctx.font = `bold ${W<400?8:9}px monospace`;
  ctx.textAlign = "center";
  labels.forEach(l => {
    ctx.fillStyle = l.col;
    ctx.fillText(l.text, l.x, l.y);
  });

  // Title
  ctx.font = `bold ${W<400?10:11}px monospace`;
  ctx.fillStyle = "#94a3b8";
  ctx.fillText("EXPLODED VIEW — تمام پارٹس الگ الگ", W/2, 14);

  // Arrow lines between parts
  ctx.strokeStyle="#334155"; ctx.lineWidth=1; ctx.setLineDash([3,3]);
  ctx.beginPath(); ctx.moveTo(W*0.38,H*0.22); ctx.lineTo(W*0.62,H*0.22); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(W*0.38,H*0.62); ctx.lineTo(W*0.62,H*0.62); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(W*0.25,H*0.35); ctx.lineTo(W*0.25,H*0.48); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(W*0.75,H*0.35); ctx.lineTo(W*0.75,H*0.48); ctx.stroke();
  ctx.setLineDash([]);
}

// ─── REACT COMPONENT ──────────────────────────────────────────────────────────
export default function BridgeModel() {
  const [view, setView]       = useState("complete");
  const [rx,   setRx]         = useState(0.38);
  const [ry,   setRy]         = useState(-0.55);
  const [spin, setSpin]       = useState(false);
  const canvasRef             = useRef(null);
  const lastTouch             = useRef(null);
  const spinRef               = useRef(false);
  const ryRef                 = useRef(-0.55);
  const rafRef                = useRef(null);

  const W = 340, H = 280;

  useEffect(() => {
    const c = canvasRef.current; if (!c) return;
    const ctx = c.getContext("2d");
    if (view === "complete") drawComplete(ctx, W, H, rx, ry);
    else drawExploded(ctx, W, H);
  }, [view, rx, ry]);

  useEffect(() => { ryRef.current = ry; }, [ry]);

  const startSpin = () => {
    spinRef.current = true; setSpin(true);
    const loop = () => {
      if (!spinRef.current) return;
      ryRef.current += 0.01; setRy(ryRef.current);
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
  };
  const stopSpin = () => {
    spinRef.current = false; setSpin(false);
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
  };

  const onTouchStart = e => { stopSpin(); lastTouch.current = {x:e.touches[0].clientX,y:e.touches[0].clientY}; };
  const onTouchMove  = e => {
    if (!lastTouch.current) return;
    e.preventDefault();
    setRy(r => r + (e.touches[0].clientX - lastTouch.current.x)*0.012);
    setRx(r => r + (e.touches[0].clientY - lastTouch.current.y)*0.006);
    lastTouch.current = {x:e.touches[0].clientX,y:e.touches[0].clientY};
  };

  const btn = (label, action, active=false, col="#1e293b") => (
    <button onClick={action} style={{
      background: active?"#1d4ed8":col, border:`1px solid ${active?"#3b82f6":"#1f2937"}`,
      color:"#f1f5f9", padding:"5px 10px", borderRadius:6, fontSize:10,
      cursor:"pointer", fontFamily:"inherit"
    }}>{label}</button>
  );

  const specs = [
    {icon:"📐", label:"کل لمبائی", val:"14 فٹ (4.27 m)", col:COL.blue},
    {icon:"↔️", label:"چوڑائی", val:"2.5 فٹ (76 cm)", col:COL.yellow},
    {icon:"📏", label:"U Channel گہرائی", val:"11 انچ (3+5+3)", col:COL.steelLight},
    {icon:"🔩", label:"U Channel موٹائی", val:"6mm MS Sheet", col:COL.steelLight},
    {icon:"🟫", label:"Checker Plate", val:"4mm × 2 شیٹ", col:COL.checker},
    {icon:"🟩", label:"Center Supports", val:"6 عدد، 6mm", col:COL.support},
    {icon:"🚧", label:"ریلنگ اونچائی", val:"3 فٹ (91 cm)", col:"#f472b6"},
    {icon:"🔧", label:"ریلنگ پائپ", val:'1.5″ گول MS Pipe', col:COL.railing},
  ];

  const weights = [
    {part:"U Channel × 2", kg:"290", note:"1 شیٹ 4×8 فٹ 6mm"},
    {part:"Center Supports × 6", kg:"25", note:"آدھی شیٹ 6mm"},
    {part:"Checker Plate", kg:"260", note:"2 شیٹ 4×8 فٹ 4mm"},
    {part:"Railing Pipe × 2", kg:"~55", note:"2×14 فٹ + پوسٹس"},
    {part:"کل وزن", kg:"~630", note:"فاؤنڈیشن مضبوط چاہیے!", bold:true},
  ];

  const materials = [
    {item:'6mm MS Sheet (4×8)', qty:"1.5 شیٹ", use:"U Channel + Supports"},
    {item:'4mm Checker Plate', qty:"2 شیٹ", use:"ڈیک"},
    {item:'1.5″ MS Pipe', qty:"~50 فٹ", use:"ریلنگ + پوسٹس"},
    {item:'3.25mm Electrode', qty:"2 پیکٹ", use:"6mm ویلڈنگ"},
  ];

  return (
    <div style={{background:COL.bg, minHeight:"100vh", color:COL.text, fontFamily:"sans-serif", direction:"rtl", fontSize:12}}>

      {/* Header */}
      <div style={{background:"linear-gradient(135deg,#0f172a,#1e293b)",borderBottom:`2px solid ${COL.steel}`,padding:"10px 14px",textAlign:"center"}}>
        <div style={{fontSize:15,fontWeight:700,color:COL.blue}}>🏗️ اسٹیل بریج / ریمپ — انجینئرنگ ڈرائنگ</div>
        <div style={{fontSize:10,color:COL.muted,marginTop:2}}>14 فٹ × 2.5 فٹ | 6mm U Channel | 4mm Checker | 3 فٹ ریلنگ</div>
      </div>

      <div style={{padding:"10px 12px"}}>

        {/* View Toggle */}
        <div style={{display:"flex",gap:6,marginBottom:8,justifyContent:"center"}}>
          {btn("✅ Complete View",  ()=>setView("complete"), view==="complete")}
          {btn("💥 Exploded View",  ()=>setView("exploded"), view==="exploded")}
          {view==="complete" && btn(spin?"⏹ رکو":"⟳ گھماؤ", spin?stopSpin:startSpin, spin, spin?"#7c2d12":"#1e293b")}
        </div>

        {/* Canvas */}
        <div style={{background:COL.panel,border:`1px solid ${COL.border}`,borderRadius:10,padding:8,marginBottom:10}}>
          <canvas ref={canvasRef} width={W} height={H}
            style={{display:"block",margin:"0 auto",borderRadius:6,touchAction:"none",maxWidth:"100%"}}
            onTouchStart={onTouchStart} onTouchMove={onTouchMove}
          />
          {view==="complete" && (
            <div style={{display:"flex",gap:10,justifyContent:"center",marginTop:6,fontSize:10,color:COL.muted,flexWrap:"wrap"}}>
              <span><span style={{color:COL.steelLight}}>■</span> U Channel 6mm</span>
              <span><span style={{color:COL.checker}}>■</span> Checker 4mm</span>
              <span><span style={{color:COL.support}}>■</span> Supports</span>
              <span><span style={{color:"#aaa"}}>■</span> Railing</span>
              <span style={{color:COL.muted}}>👆 انگلی سے گھمائیں</span>
            </div>
          )}
        </div>

        {/* Specs Grid */}
        <div style={{background:COL.panel,border:`1px solid ${COL.border}`,borderRadius:8,padding:10,marginBottom:10}}>
          <div style={{fontWeight:700,color:COL.blue,marginBottom:8,fontSize:11}}>📋 ڈیزائن اسپیسیفیکیشن</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
            {specs.map((s,i)=>(
              <div key={i} style={{background:"#0f172a",borderRadius:6,padding:"6px 8px",borderRight:`3px solid ${s.col}`}}>
                <div style={{fontSize:9,color:COL.muted}}>{s.icon} {s.label}</div>
                <div style={{fontSize:11,fontWeight:600,color:s.col,marginTop:1}}>{s.val}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Weight Table */}
        <div style={{background:COL.panel,border:`1px solid ${COL.border}`,borderRadius:8,padding:10,marginBottom:10}}>
          <div style={{fontWeight:700,color:COL.yellow,marginBottom:8,fontSize:11}}>⚖️ وزن کا تخمینہ</div>
          {weights.map((w,i)=>(
            <div key={i} style={{
              display:"flex",justifyContent:"space-between",alignItems:"center",
              padding:"5px 0",borderBottom:`1px solid ${i===weights.length-1?"transparent":"#1e293b"}`,
              background: w.bold?"#1a2a1a":"transparent",borderRadius:w.bold?4:0,
              padding:w.bold?"6px 8px":"5px 0"
            }}>
              <div>
                <span style={{fontWeight:w.bold?700:400,color:w.bold?COL.green:COL.text,fontSize:11}}>{w.part}</span>
                <div style={{fontSize:9,color:COL.muted}}>{w.note}</div>
              </div>
              <span style={{fontWeight:700,color:w.bold?COL.green:COL.yellow,fontSize:w.bold?14:11,direction:"ltr"}}>{w.kg} kg</span>
            </div>
          ))}
        </div>

        {/* Load Capacity */}
        <div style={{background:"linear-gradient(135deg,#1a1a2e,#0f172a)",border:`2px solid ${COL.green}`,borderRadius:8,padding:12,marginBottom:10}}>
          <div style={{fontWeight:700,color:COL.green,marginBottom:6,fontSize:11}}>🚛 اندازاً لوڈ کیپیسٹی</div>
          {[
            {load:"محفوظ کام کا بوجھ",val:"1,500–2,000 kg",note:"6mm U Channel + 6 Supports کے ساتھ",col:COL.green},
            {load:"زیادہ سے زیادہ (بریکنگ)",val:"~4,000–5,000 kg",note:"ایک بار — سیفٹی فیکٹر 2.5×",col:COL.yellow},
            {load:"موٹرسائیکل / چھوٹی گاڑی",val:"✅ آسانی سے",note:"",col:COL.blue},
            {load:"چھوٹا ٹریکٹر / ٹرالی",val:"✅ محفوظ",note:"",col:COL.blue},
            {load:"بھاری ٹرک (10+ ٹن)",val:"⚠️ مشورہ نہیں",note:"فاؤنڈیشن اور اسپین بھی دیکھیں",col:COL.red},
          ].map((l,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",borderBottom:`1px solid #1e293b`,padding:"4px 0",fontSize:10}}>
              <span style={{color:COL.muted}}>{l.load}</span>
              <div style={{textAlign:"left"}}>
                <span style={{color:l.col,fontWeight:600}}>{l.val}</span>
                {l.note&&<div style={{fontSize:9,color:COL.muted}}>{l.note}</div>}
              </div>
            </div>
          ))}
        </div>

        {/* Materials */}
        <div style={{background:COL.panel,border:`1px solid ${COL.border}`,borderRadius:8,padding:10,marginBottom:10}}>
          <div style={{fontWeight:700,color:"#f472b6",marginBottom:8,fontSize:11}}>🛒 شیٹس اور مواد کی فہرست</div>
          {materials.map((m,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:`1px solid #1e293b`,padding:"5px 0",fontSize:10}}>
              <div>
                <span style={{color:COL.text}}>{m.item}</span>
                <div style={{fontSize:9,color:COL.muted}}>{m.use}</div>
              </div>
              <span style={{color:"#f472b6",fontWeight:700}}>{m.qty}</span>
            </div>
          ))}
        </div>

        {/* Railing calc */}
        <div style={{background:"#0f1a0f",border:`1px solid ${COL.support}`,borderRadius:8,padding:10,marginBottom:10}}>
          <div style={{fontWeight:700,color:"#86efac",marginBottom:6,fontSize:11}}>🔧 ریلنگ پائپ حساب</div>
          {[
            "دونوں سائیڈ ٹاپ ریل: 2 × 14 فٹ = 28 فٹ",
            "دونوں سائیڈ مڈ ریل: 2 × 14 فٹ = 28 فٹ",
            "ورٹیکل پوسٹس: 18 عدد × 3 فٹ = 54 فٹ",
            "کل پائپ: ~110 فٹ (1.5\" گول MS)",
            "وزن: ~55 کلو | ریٹ ~200 ₨/kg = ~11,000 ₨",
          ].map((t,i)=>(
            <div key={i} style={{fontSize:10,color:i===4?COL.green:COL.muted,padding:"2px 0",borderBottom:`1px solid #1a2a1a`}}>
              {i===4?"→ ":"• "}{t}
            </div>
          ))}
        </div>

        {/* Grand Total */}
        <div style={{background:"linear-gradient(135deg,#1a0f0a,#2d1a0a)",border:`2px solid ${COL.yellow}`,borderRadius:10,padding:14,textAlign:"center",marginBottom:10}}>
          <div style={{color:COL.muted,fontSize:11,marginBottom:4}}>مکمل بریج — تخمینی کل لاگت</div>
          <div style={{fontSize:13,color:COL.text,marginBottom:4}}>
            شیٹ/پلیٹ: ₨1,14,700 + ریلنگ: ₨11,000
          </div>
          <div style={{fontSize:26,fontWeight:700,color:COL.yellow,direction:"ltr"}}>≈ ₨ 1,25,700</div>
          <div style={{color:COL.muted,fontSize:10,marginTop:4}}>ویلڈنگ لیبر + کٹنگ + مارکیٹ تبدیلی الگ</div>
        </div>

      </div>
    </div>
  );
}